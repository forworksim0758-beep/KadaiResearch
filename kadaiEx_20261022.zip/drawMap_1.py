## drawMap_1.py
import sys
import numpy as np
import pygame
from data_gen_1 import Simulation, SIM_DT, DEFAULT_PARAMS, WORLD_W, WORLD_H, EDGE_MODES
from schema_1 import ORBIT, SCENARIOS, det_dtype
from ui_1 import Slider, Dropdown, Button, PANEL_BG, SUBTLE
from camera_1 import Camera, VIEW_MODES
from radar_1 import Radar, SCAN_MODES

MAP_W, MAP_H = 800, 800
PANEL_W = 300
MAP_RECT = pygame.Rect(0, 0, MAP_W, MAP_H)

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
OUTSIDE = (38, 38, 46)
BORDER = (90, 90, 105)
FOCUS = (255, 210, 60)
DET = (60, 230, 120)
BEAM = (40, 110, 60)
FACE_OPTIONS = ["1", "2", "4", "8"]
HELP_LINES = ("Click target: follow", "Click empty: move center",
              "Click center: home   Wheel: zoom")
MAX_STEPS_PER_FRAME = 400
PICK_PX = 8
HOME_PX = 10
SCALE_BAR_PX = 120

VISIBLE_IF = {
    "initial": lambda s, o: s in ("random", "flock", "inbound"),
    "spawn_rate": lambda s, o: s in ("random", "flock", "inbound"),
    "flock_size": lambda s, o: s == "flock",
    "flock_spread": lambda s, o: s == "flock",
    "cross_n": lambda s, o: s == "crossing",
    "cross_angle": lambda s, o: s == "crossing",
    "turn_accel": lambda s, o: o in ("turn", "maneuver"),
}


def buildSliders():
    p = DEFAULT_PARAMS
    return {
        "seed": Slider("Seed (Reset)", 0, 99, p["seed"], 1),
        "speed": Slider("Speed [m/s]", 10, 300, p["speed"], 1),
        "initial": Slider("Initial targets/flocks (Reset)", 0, 30, p["initial"], 1),
        "spawn_rate": Slider("Spawn rate [/min]", 0, 60, p["spawn_rate"], 1),
        "turn_accel": Slider("Turn accel [m/s^2]", 0, 30, p["turn_accel"], 0.5, "{:.1f}"),
        "flock_size": Slider("Flock size", 2, 12, p["flock_size"], 1),
        "flock_spread": Slider("Flock spread [m]", 20, 1000, p["flock_spread"], 10),
        "cross_n": Slider("Crossing targets", 2, 6, p["cross_n"], 1),
        "cross_angle": Slider("Crossing angle [deg]", 5, 180, p["cross_angle"], 1),
    }


def layout(dropdowns, sliders, time_scale, buttons):
    x = MAP_W + 20
    w = PANEL_W - 40
    y = 15
    half = (w - 10) // 2
    for d in dropdowns[:3]:
        y = d.place(x, y, w)
    dropdowns[3].place(x, y, half)
    y = dropdowns[4].place(x + half + 10, y, half)
    scenario, orbit = dropdowns[0].value, dropdowns[1].value
    for key, s in sliders.items():
        rule = VISIBLE_IF.get(key)
        s.visible = rule is None or rule(scenario, orbit)
        if s.visible:
            y = s.place(x, y, w)
    y = time_scale.place(x, y + 10, w)
    buttons[0].place(x, y + 10, half)
    y = buttons[1].place(x + half + 10, y + 10, half)
    buttons[2].place(x, y, half)
    buttons[3].place(x + half + 10, y, half)


def edgeLabel(mode):
    return f"Edge: {mode}"


def pickTarget(sim, cam, pos):
    e = sim.enemies
    idx = np.flatnonzero(e["alive"])
    if idx.size == 0:
        return -1
    sx, sy = cam.toScreen(e["x"][idx], e["y"][idx])
    d = np.hypot(sx - pos[0], sy - pos[1])
    k = int(np.argmin(d))
    if d[k] > PICK_PX:
        return -1
    return int(idx[k])


def niceLength(m):
    p = 10 ** np.floor(np.log10(m))
    for k in (5, 2, 1):
        if k * p <= m:
            return k * p
    return p


def drawScale(screen, font, cam):
    length = niceLength(SCALE_BAR_PX / cam.zoom)
    px = int(round(length * cam.zoom))
    x, y = 20, MAP_H - 25
    pygame.draw.line(screen, WHITE, (x, y), (x + px, y), 2)
    pygame.draw.line(screen, WHITE, (x, y - 5), (x, y + 5), 1)
    pygame.draw.line(screen, WHITE, (x + px, y - 5), (x + px, y + 5), 1)
    label = f"{length / 1000:g} km" if length >= 1000 else f"{length:g} m"
    screen.blit(font.render(label, True, WHITE), (x, y - 20))


def drawRadar(screen, sim, cam, radar, dets):
    cx, cy = cam.toScreen(radar.cx, radar.cy)
    if radar.params["scan"] == "mechanical":
        for a in radar.beamAngles(sim.t):
            ex, ey = cam.toScreen(radar.cx + radar.params["r_max"] * np.cos(a),
                                  radar.cy + radar.params["r_max"] * np.sin(a))
            pygame.draw.line(screen, BEAM, (round(cx), round(cy)), (round(ex), round(ey)), 1)
    if dets.size == 0:
        return
    age = np.clip((sim.t - dets["t"]) / radar.params["t_rot"], 0.0, 1.0)
    sx, sy = cam.toScreen(dets["x"], dets["y"])
    inside = (sx > -10) & (sx < MAP_W + 10) & (sy > -10) & (sy < MAP_H + 10)
    for x, y, a in zip(sx[inside], sy[inside], age[inside]):
        color = tuple(int(c * (1 - 0.8 * a)) for c in DET)
        pygame.draw.rect(screen, color, pygame.Rect(round(x) - 2, round(y) - 2, 5, 5), 1)


def drawWorld(screen, font, sim, cam, radar, dets, show_truth):
    screen.set_clip(MAP_RECT)
    screen.fill(OUTSIDE, MAP_RECT)
    x0, y0 = cam.toScreen(0.0, 0.0)
    x1, y1 = cam.toScreen(sim.width, sim.height)
    world = pygame.Rect(round(x0), round(y0), round(x1 - x0), round(y1 - y0))
    screen.fill(BLACK, world.clip(MAP_RECT))
    pygame.draw.rect(screen, BORDER, world, 1)
    drawRadar(screen, sim, cam, radar, dets)

    e = sim.enemies
    if show_truth:
        idx = np.flatnonzero(e["alive"])
        sx, sy = cam.toScreen(e["x"][idx], e["y"][idx])
        hx = sx + 10 * np.cos(e["angle"][idx])
        hy = sy + 10 * np.sin(e["angle"][idx])
        inside = (sx > -20) & (sx < MAP_W + 20) & (sy > -20) & (sy < MAP_H + 20)
        for i, x, y, x2, y2 in zip(idx[inside], sx[inside], sy[inside], hx[inside], hy[inside]):
            color = WHITE if e["leader"][i] >= 0 else RED
            p = (round(x), round(y))
            pygame.draw.circle(screen, color, p, 3)
            pygame.draw.line(screen, color, p, (round(x2), round(y2)), 1)
        if cam.follow >= 0:
            fx, fy = cam.toScreen(e["x"][cam.follow], e["y"][cam.follow])
            pygame.draw.circle(screen, FOCUS, (round(fx), round(fy)), 9, 1)

    cx, cy = MAP_RECT.center
    pygame.draw.line(screen, SUBTLE, (cx - 6, cy), (cx + 6, cy), 1)
    pygame.draw.line(screen, SUBTLE, (cx, cy - 6), (cx, cy + 6), 1)

    drawScale(screen, font, cam)
    info = f"t = {sim.t:7.2f} s   alive = {int(e['alive'].sum())}   issued = {sim.next_id - 1}"
    screen.blit(font.render(info, True, WHITE), (10, 10))
    view = f"view {cam.viewWidth() / 1000:.2f} km   x{cam.zoomRatio():.1f}"
    if cam.follow >= 0:
        view += f"   follow id {cam.follow_id}"
    screen.blit(font.render(view, True, WHITE), (10, 30))
    p = radar.params
    rinfo = (f"radar {p['scan']} N={radar.n}   Trot {p['t_rot']:.1f} s   "
             f"dets {radar.n_det}   seam doubles {radar.seam_doubles}")
    screen.blit(font.render(rinfo, True, WHITE), (10, 50))
    for k, line in enumerate(HELP_LINES):
        screen.blit(font.render(line, True, SUBTLE), (MAP_W - 250, MAP_H - 64 + 18 * k))
    screen.set_clip(None)


def drawPanel(screen, font, dropdowns, sliders, time_scale, buttons):
    pygame.draw.rect(screen, PANEL_BG, pygame.Rect(MAP_W, 0, PANEL_W, MAP_H))
    for d in dropdowns:
        d.draw(screen, font)
    for s in sliders.values():
        s.draw(screen, font)
    time_scale.draw(screen, font)
    for b in buttons:
        b.draw(screen, font)

    lx, ly = MAP_W + 20, MAP_H - 88
    screen.blit(font.render("Ground truth (user only)", True, SUBTLE), (lx, ly))
    pygame.draw.circle(screen, RED, (lx + 5, ly + 27), 4)
    screen.blit(font.render("leader / single", True, SUBTLE), (lx + 16, ly + 20))
    pygame.draw.circle(screen, WHITE, (lx + 5, ly + 47), 4)
    screen.blit(font.render("follower", True, SUBTLE), (lx + 16, ly + 40))
    pygame.draw.rect(screen, DET, pygame.Rect(lx + 3, ly + 65, 5, 5), 1)
    screen.blit(font.render("detection (tracker input)", True, SUBTLE), (lx + 16, ly + 60))

    for d in dropdowns:
        d.drawList(screen, font)


def main():
    pygame.init()
    screen = pygame.display.set_mode((MAP_W + PANEL_W, MAP_H))
    pygame.display.set_caption("Radar target simulator")
    font = pygame.font.SysFont(None, 20)
    clock = pygame.time.Clock()

    sim = Simulation(WORLD_W, WORLD_H)
    cam = Camera(WORLD_W, WORLD_H, MAP_RECT.x, MAP_RECT.y, MAP_W, MAP_H)
    radar = Radar(sim.cx, sim.cy, seed=sim.params["seed"])
    recent = []
    orbits = list(ORBIT)
    view_mode = Dropdown("View (when zoomed out)", VIEW_MODES, 0)
    dropdowns = (
        Dropdown("Scenario", SCENARIOS, SCENARIOS.index(sim.params["scenario"])),
        Dropdown("Orbit", orbits, orbits.index(sim.params["orbit"])),
        view_mode,
        Dropdown("Scan", SCAN_MODES, SCAN_MODES.index(radar.params["scan"])),
        Dropdown("Faces N", FACE_OPTIONS, FACE_OPTIONS.index(str(radar.n))),
    )
    sliders = buildSliders()
    time_scale = Slider("Time scale", 0.25, 16.0, 1.0, 0.25, "{:.2f}x")
    buttons = (Button("Reset"), Button("Pause"), Button("Hide truth"),
               Button(edgeLabel(sim.params["edge"])))

    acc = 0.0
    paused = False
    show_truth = True

    def doReset():
        nonlocal acc
        for key, s in sliders.items():
            sim.params[key] = s.value
        sim.params["scenario"] = dropdowns[0].value
        sim.params["orbit"] = dropdowns[1].value
        sim.reset()
        radar.params["scan"] = dropdowns[3].value
        radar.params["n_faces"] = int(dropdowns[4].value)
        radar.reset(sim.params["seed"])
        recent.clear()
        acc = 0.0

    def handleMap(event):
        if event.type == pygame.MOUSEWHEEL:
            if MAP_RECT.collidepoint(pygame.mouse.get_pos()):
                cam.zoomBy(event.y)
                return True
            return False
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        if not MAP_RECT.collidepoint(event.pos):
            return False
        hit = pickTarget(sim, cam, event.pos) if show_truth else -1
        near_center = np.hypot(event.pos[0] - MAP_RECT.centerx,
                               event.pos[1] - MAP_RECT.centery) <= HOME_PX
        if hit >= 0 and hit != cam.follow:
            cam.followTarget(hit, int(sim.enemies["id"][hit]))
        elif hit >= 0 or near_center:
            cam.home()
        else:
            cam.focusAt(*cam.toWorld(*event.pos))
        return True

    def handleEvent(event):
        nonlocal paused, show_truth
        for d in dropdowns:
            if d.open:
                if d.handle(event) and d is not view_mode:
                    doReset()
                return
        for d in dropdowns:
            d.handle(event)
            if d.open:
                return
        if handleMap(event):
            return
        for key, s in sliders.items():
            if s.handle(event):
                sim.params[key] = s.value
        time_scale.handle(event)
        if buttons[0].handle(event):
            doReset()
        if buttons[1].handle(event):
            paused = not paused
            buttons[1].text = "Resume" if paused else "Pause"
        if buttons[2].handle(event):
            show_truth = not show_truth
            buttons[2].text = "Hide truth" if show_truth else "Show truth"
        if buttons[3].handle(event):
            k = EDGE_MODES.index(sim.params["edge"])
            sim.params["edge"] = EDGE_MODES[(k + 1) % len(EDGE_MODES)]
            buttons[3].text = edgeLabel(sim.params["edge"])

    running = True
    while running:
        real_dt = clock.tick(60) / 1000
        layout(dropdowns, sliders, time_scale, buttons)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                handleEvent(event)

        if not paused:
            acc += real_dt * time_scale.value
            steps = 0
            while acc >= SIM_DT and steps < MAX_STEPS_PER_FRAME:
                sim.step(SIM_DT)
                recent.append(radar.scan(sim))
                acc -= SIM_DT
                steps += 1
            if acc >= SIM_DT:
                acc = 0.0

        recent[:] = [d for d in recent if d.size and d["t"][-1] > sim.t - radar.params["t_rot"]]
        dets = np.concatenate(recent) if recent else np.zeros(0, dtype=det_dtype)

        cam.mode = view_mode.value
        cam.update(sim.enemies)
        drawWorld(screen, font, sim, cam, radar, dets, show_truth)
        drawPanel(screen, font, dropdowns, sliders, time_scale, buttons)
        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
