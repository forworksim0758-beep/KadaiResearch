import numpy as np
from schema_1 import det_dtype
from config_1 import T_ROT, N_FACES, SCAN, R_MIN, R_MAX, SIGMA_R, SIGMA_TH, PD, FA_PER_SCAN

SCAN_MODES = ["mechanical", "electronic"]

RADAR_DEFAULTS = {
    "scan": SCAN,
    "n_faces": N_FACES,
    "t_rot": T_ROT,
    "r_min": R_MIN,
    "r_max": R_MAX,
    "sigma_r": SIGMA_R,
    "sigma_th": SIGMA_TH,
    "pd": PD,
    "fa_per_scan": FA_PER_SCAN,
}


def wrapAngle(a):
    return np.arctan2(np.sin(a), np.cos(a))


class Radar:
    def __init__(self, cx, cy, params=None, seed=0):
        self.cx = cx
        self.cy = cy
        self.params = dict(RADAR_DEFAULTS)
        if params:
            self.params.update(params)
        self.reset(seed)

    def reset(self, seed):
        p = self.params
        self.rng = np.random.default_rng([int(seed), 1])
        self.phi0 = self.rng.uniform(0, 2 * np.pi)
        self.omega = 2 * np.pi / p["t_rot"]
        self.n = int(p["n_faces"])
        self.frame_t = p["t_rot"] / self.n
        self.band = p["r_max"] ** 2 - p["r_min"] ** 2
        self.lam = p["fa_per_scan"] / (np.pi * self.band)
        self.prev = None
        self.log = []
        self.truth_log = []
        self.last_frame = {}
        self.seam_doubles = 0
        self.n_det = 0

    def beamAngles(self, t):
        return self.phi0 + self.omega * t + 2 * np.pi * np.arange(self.n) / self.n

    def mechanicalHits(self, t0, t1, x0, y0, x1, y1, tid):
        th0 = np.arctan2(y0 - self.cy, x0 - self.cx)
        th1 = np.arctan2(y1 - self.cy, x1 - self.cx)
        d0 = wrapAngle(th0[None, :] - self.beamAngles(t0)[:, None])
        d1 = wrapAngle(th1[None, :] - self.beamAngles(t1)[:, None])
        hit = ((d0 > 0) != (d1 > 0)) & (np.abs(d0 - d1) < np.pi)
        face, k = np.nonzero(hit)
        f = d0[face, k] / (d0[face, k] - d1[face, k])
        t = t0 + f * (t1 - t0)
        x = x0[k] + f * (x1[k] - x0[k])
        y = y0[k] + f * (y1[k] - y0[k])
        return t, x, y, tid[k], face

    def frameCenters(self, t0, t1):
        lo = int(np.floor(t0 / self.frame_t - 0.5)) + 1
        hi = int(np.floor(t1 / self.frame_t - 0.5))
        return (np.arange(lo, hi + 1) + 0.5) * self.frame_t

    def electronicHits(self, t0, t1, x0, y0, x1, y1, tid):
        centers = self.frameCenters(t0, t1)
        f = ((centers - t0) / (t1 - t0))[:, None]
        t = np.repeat(centers, tid.size)
        x = (x0[None, :] + f * (x1 - x0)[None, :]).ravel()
        y = (y0[None, :] + f * (y1 - y0)[None, :]).ravel()
        return t, x, y, np.tile(tid, centers.size), np.zeros(t.size, dtype=int)

    def measure(self, t, x, y, tid, face):
        p = self.params
        r = np.hypot(x - self.cx, y - self.cy)
        az = np.arctan2(y - self.cy, x - self.cx)
        keep = (r >= p["r_min"]) & (r <= p["r_max"]) & (self.rng.random(r.size) < p["pd"])
        t, r, az, tid, face = t[keep], r[keep], az[keep], tid[keep], face[keep]
        r = r + self.rng.normal(0.0, p["sigma_r"], r.size)
        az = wrapAngle(az + self.rng.normal(0.0, p["sigma_th"], az.size))
        return t, r, az, tid, face

    def randomRange(self, k):
        p = self.params
        return np.sqrt(self.rng.uniform(p["r_min"] ** 2, p["r_max"] ** 2, k))

    def clutterSweep(self, t0, t1):
        dphi = self.omega * (t1 - t0)
        k = self.rng.poisson(self.lam * 0.5 * dphi * self.band * self.n)
        u = self.rng.random(k)
        face = self.rng.integers(0, self.n, k)
        t = t0 + u * (t1 - t0)
        az = wrapAngle(self.beamAngles(t0)[face] + u * dphi)
        return t, self.randomRange(k), az, np.full(k, -1), face

    def clutterFlash(self, t0, t1):
        centers = self.frameCenters(t0, t1)
        k = self.rng.poisson(self.lam * np.pi * self.band, centers.size)
        t = np.repeat(centers, k)
        az = self.rng.uniform(-np.pi, np.pi, t.size)
        return t, self.randomRange(t.size), az, np.full(t.size, -1), np.zeros(t.size, dtype=int)

    def countSeamDoubles(self, tid, frame):
        for i, f in zip(tid, frame):
            if i < 0:
                continue
            if self.last_frame.get(i) == f:
                self.seam_doubles += 1
            self.last_frame[i] = f

    def scan(self, sim):
        e = sim.enemies
        cur = (sim.t, e["x"].copy(), e["y"].copy(), e["id"].copy(), e["alive"].copy())
        prev = self.prev
        self.prev = cur
        if prev is None or cur[0] <= prev[0]:
            return np.zeros(0, dtype=det_dtype)
        t0, x0, y0, id0, a0 = prev
        t1, x1, y1, id1, a1 = cur
        k = np.flatnonzero(a0 & a1 & (id0 == id1))
        args = (t0, t1, x0[k], y0[k], x1[k], y1[k], id1[k])
        if self.params["scan"] == "electronic":
            hits = self.measure(*self.electronicHits(*args))
            noise = self.clutterFlash(t0, t1)
        else:
            hits = self.measure(*self.mechanicalHits(*args))
            noise = self.clutterSweep(t0, t1)
        t, r, az, tid, face = (np.concatenate([a, b]) for a, b in zip(hits, noise))

        order = np.argsort(t, kind="stable")
        det = np.zeros(t.size, dtype=det_dtype)
        det["t"] = t[order]
        det["r"] = r[order]
        det["az"] = az[order]
        det["x"] = self.cx + det["r"] * np.cos(det["az"])
        det["y"] = self.cy + det["r"] * np.sin(det["az"])
        det["face"] = face[order]
        det["frame"] = np.floor(det["t"] / self.frame_t)
        truth = tid[order].astype(np.int32)

        self.countSeamDoubles(truth, det["frame"])
        self.n_det += det.size
        self.log.append(det)
        self.truth_log.append(truth)
        return det

    def detections(self):
        if not self.log:
            return np.zeros(0, dtype=det_dtype)
        return np.concatenate(self.log)

    def truths(self):
        if not self.truth_log:
            return np.zeros(0, dtype=np.int32)
        return np.concatenate(self.truth_log)
