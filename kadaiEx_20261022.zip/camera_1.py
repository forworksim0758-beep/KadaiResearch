ZOOM_STEP = 1.25
MIN_VIEW_M = 200.0
BLEND_ZOOM = 2.0
VIEW_MODES = ["blend", "clamp", "free"]


class Camera:
    def __init__(self, world_w, world_h, view_x, view_y, view_w, view_h):
        self.world_w = world_w
        self.world_h = world_h
        self.vx = view_x
        self.vy = view_y
        self.vw = view_w
        self.vh = view_h
        self.fit = min(view_w / world_w, view_h / world_h)
        self.zoom_max = min(view_w, view_h) / MIN_VIEW_M
        self.mode = VIEW_MODES[0]
        self.home()

    def home(self):
        self.fx = self.world_w / 2
        self.fy = self.world_h / 2
        self.zoom = self.fit
        self.follow = -1
        self.follow_id = 0

    def clampAxis(self, f, world, view):
        half = view / (2 * self.zoom)
        if 2 * half >= world:
            return world / 2
        return min(max(f, half), world - half)

    def center(self):
        if self.mode == "free":
            return self.fx, self.fy
        if self.mode == "clamp":
            return (self.clampAxis(self.fx, self.world_w, self.vw),
                    self.clampAxis(self.fy, self.world_h, self.vh))
        wx = self.world_w / 2
        wy = self.world_h / 2
        w = min(max((self.zoom / self.fit - 1) / (BLEND_ZOOM - 1), 0.0), 1.0)
        return wx + (self.fx - wx) * w, wy + (self.fy - wy) * w

    def toScreen(self, x, y):
        cx, cy = self.center()
        sx = self.vx + self.vw / 2 + (x - cx) * self.zoom
        sy = self.vy + self.vh / 2 + (y - cy) * self.zoom
        return sx, sy

    def toWorld(self, sx, sy):
        cx, cy = self.center()
        x = cx + (sx - self.vx - self.vw / 2) / self.zoom
        y = cy + (sy - self.vy - self.vh / 2) / self.zoom
        return x, y

    def zoomBy(self, notches):
        z = self.zoom * ZOOM_STEP ** notches
        self.zoom = min(max(z, self.fit), self.zoom_max)

    def focusAt(self, x, y):
        self.fx = min(max(x, 0.0), self.world_w)
        self.fy = min(max(y, 0.0), self.world_h)
        self.follow = -1

    def followTarget(self, slot, target_id):
        self.follow = slot
        self.follow_id = target_id

    def update(self, enemies):
        if self.follow < 0:
            return
        e = enemies[self.follow]
        if not e["alive"] or e["id"] != self.follow_id:
            self.follow = -1
            return
        self.fx = float(e["x"])
        self.fy = float(e["y"])

    def viewWidth(self):
        return self.vw / self.zoom

    def zoomRatio(self):
        return self.zoom / self.fit
