import numpy as np

R_MAX = 10000.0
R_MIN = 500.0
WORLD_W = 2 * R_MAX
WORLD_H = 2 * R_MAX

T_ROT = 2.0
N_FACES = 1
SCAN = "mechanical"
SIGMA_R = 30.0
SIGMA_TH = np.deg2rad(0.3)
PD = 0.9
FA_PER_SCAN = 10.0
