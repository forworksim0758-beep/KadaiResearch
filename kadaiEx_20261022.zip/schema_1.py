import numpy as np

enemy_dtype = np.dtype([
    ("id", np.int32),
    ("alive", np.bool_),
    ("x", np.float64),
    ("y", np.float64),
    ("angle", np.float64),
    ("speed", np.float64),
    ("orbit", np.int8),
    ("leader", np.int32),
    ("ox", np.float64),
    ("oy", np.float64),
    ("turn_sign", np.float64),
    ("man_t", np.float64),
])

det_dtype = np.dtype([
    ("t", np.float64),
    ("r", np.float64),
    ("az", np.float64),
    ("x", np.float64),
    ("y", np.float64),
    ("face", np.int8),
    ("frame", np.int32),
])

ORBIT = {
    "straight": 0,
    "turn": 1,
    "maneuver": 2,
}

SCENARIOS = ["random", "flock", "crossing", "inbound"]
